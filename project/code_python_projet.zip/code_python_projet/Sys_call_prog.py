from PyQt5 import QtCore, QtGui, QtWidgets
import subprocess


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1048, 582)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.fork_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: fork_func())
        self.fork_but.setGeometry(QtCore.QRect(60, 70, 91, 21))
        self.fork_but.setObjectName("fork_but")
        self.getpid_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: getpid_func())
        self.getpid_but.setGeometry(QtCore.QRect(200, 70, 89, 25))
        self.getpid_but.setObjectName("getpid_but")
        self.getppid_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: getppid_func())
        self.getppid_but.setGeometry(QtCore.QRect(340, 70, 89, 25))
        self.getppid_but.setObjectName("getppid_but")
        self.wait_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: wait_func())
        self.wait_but.setGeometry(QtCore.QRect(470, 70, 89, 25))
        self.wait_but.setObjectName("wait_but")
        self.kill_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: kill_func())
        self.kill_but.setGeometry(QtCore.QRect(60, 140, 89, 25))
        self.kill_but.setObjectName("kill_but")
        self.exec_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: exec_func())
        self.exec_but.setGeometry(QtCore.QRect(200, 140, 89, 25))
        self.exec_but.setObjectName("exec_but")
        self.dup_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: dup_func())
        self.dup_but.setGeometry(QtCore.QRect(340, 140, 89, 25))
        self.dup_but.setObjectName("dup_but")
        self.system_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: system_func())
        self.system_but.setGeometry(QtCore.QRect(470, 140, 89, 25))
        self.system_but.setObjectName("system_but")
        self.sig_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: signal_func())
        self.sig_but.setGeometry(QtCore.QRect(60, 210, 89, 25))
        self.sig_but.setObjectName("sig_but")
        self.pipe_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: pipe_func())
        self.pipe_but.setGeometry(QtCore.QRect(200, 210, 89, 25))
        self.pipe_but.setObjectName("pipe_but")
        self.mkfifo_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: mkfifo_func())
        self.mkfifo_but.setGeometry(QtCore.QRect(340, 210, 89, 25))
        self.mkfifo_but.setObjectName("mkfifo_but")
        self.alarm_but = QtWidgets.QPushButton(self.centralwidget, clicked= lambda: alarm_func())
        self.alarm_but.setGeometry(QtCore.QRect(470, 210, 89, 25))
        self.alarm_but.setObjectName("alarm_but")
        self.tabWidget = QtWidgets.QTabWidget(self.centralwidget)
        self.tabWidget.setGeometry(QtCore.QRect(600, 0, 441, 531))
        self.tabWidget.setObjectName("tabWidget")
        self.Programme_tab = QtWidgets.QWidget()
        self.Programme_tab.setObjectName("Programme_tab")
        self.textEdit = QtWidgets.QTextEdit(self.Programme_tab)
        self.textEdit.setGeometry(QtCore.QRect(0, 0, 441, 501))
        self.textEdit.setObjectName("textEdit")
        self.tabWidget.addTab(self.Programme_tab, "")
        self.output_tab = QtWidgets.QWidget()
        self.output_tab.setObjectName("output_tab")
        self.textEdit_2 = QtWidgets.QTextEdit(self.output_tab)
        self.textEdit_2.setGeometry(QtCore.QRect(0, 0, 441, 501))
        self.textEdit_2.setObjectName("textEdit_2")
        self.tabWidget.addTab(self.output_tab, "")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.centralwidget)
        self.plainTextEdit.setGeometry(QtCore.QRect(20, 290, 571, 221))
        font = QtGui.QFont()
        font.setPointSize(11)
        self.plainTextEdit.setFont(font)
        self.plainTextEdit.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.plainTextEdit.setObjectName("plainTextEdit")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    


        def getpid_func():
            self.plainTextEdit.setPlainText("getpid() returns the process ID (PID) of the calling process.")
            output_prog = subprocess.run(["cat", "arbre.c"], capture_output=True)
            output = subprocess.run("./arbre", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')


        def getppid_func():
            self.plainTextEdit.setPlainText("getppid() returns the process ID of the parent of the calling  process.")
            output_prog = subprocess.run(["cat", "date.c"], capture_output=True)
            output = subprocess.run("./date", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')

        def fork_func():
            self.plainTextEdit.setPlainText("fork() creates a new process by duplicating the calling process.The new process is referred to as the child process. The calling process is referred to as the parent process.")
            output_prog = subprocess.run(["cat", "forkboucle.c"], capture_output=True)
            output = subprocess.run("./forkboucle", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')


        def wait_func():
            self.plainTextEdit.setPlainText("The wait() system call suspends execution of the calling  thread  until one  of its children terminates.")
            output_prog = subprocess.run(["cat", "wait.c"], capture_output=True)
            output = subprocess.run("./wait", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')




        def kill_func():
            self.plainTextEdit.setPlainText("The kill() system call can be used to send any signal to any process group or process.")
            output_prog = subprocess.run(["cat", "kill.c"], capture_output=True)
            output = subprocess.run("./kill", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')


        def exec_func():
            self.plainTextEdit.setPlainText("The  exec() family of functions replaces the current process image with a new process image.")
            output_prog = subprocess.run(["cat", "execlp.c"], capture_output=True)
            output = subprocess.run("./execlp", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')


        def dup_func():
            self.plainTextEdit.setPlainText("The  dup() system call creates a copy of the file descriptor oldfd, using the lowest-numbered unused file descriptor for the new descriptor.")
            output_prog = subprocess.run(["cat", "desc_file.c"], capture_output=True)
            output = subprocess.run("./desc_file", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')

        def system_func():
            self.plainTextEdit.setPlainText("The  system()  library  function uses fork(2) to create a child process that executes the shell command specified in command using execl(3)")
            output_prog = subprocess.run(["cat", "system.c"], capture_output=True)
            output = subprocess.run("./system", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')

        def signal_func():
            self.plainTextEdit.setPlainText("signal() sets the disposition of the signal signum to handler, which is either SIG_IGN, SIG_DFL, or the address of a programmer-defined function (a 'signal handler').")
            output_prog = subprocess.run(["cat", "exp-sig.c"], capture_output=True)
            output = subprocess.run("./exp-sig", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')


        def pipe_func():
            self.plainTextEdit.setPlainText("pipe()  creates  a pipe, a unidirectional data channel that can be used for interprocess communication.")
            output_prog = subprocess.run(["cat", "pip.c"], capture_output=True)
            output = subprocess.run("./pip", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')

        def mkfifo_func():
            self.plainTextEdit.setPlainText("Create named pipes (FIFOs) with the given NAMEs.")
            output_prog = subprocess.run(["cat", "named_tube.c"], capture_output=True)
            output = subprocess.run("./named_tube", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')

        def alarm_func():
            self.plainTextEdit.setPlainText("alarm()  arranges  for  a SIGALRM signal to be delivered to the calling process in seconds seconds.")
            output_prog = subprocess.run(["cat", "alarm.c"], capture_output=True)
            output = subprocess.run("./alarm", capture_output=True)
            #p = output.stdout.decode()
            self.textEdit_2.setPlainText("")
            self.textEdit.setPlainText("")
            self.textEdit_2.insertPlainText(f' {output.stdout.decode()}')
            self.textEdit.insertPlainText(f' {output_prog.stdout.decode()}')



    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "System Calls"))
        self.fork_but.setText(_translate("MainWindow", "Fork"))
        self.getpid_but.setText(_translate("MainWindow", "getpid"))
        self.getppid_but.setText(_translate("MainWindow", "getppid"))
        self.wait_but.setText(_translate("MainWindow", "Wait"))
        self.kill_but.setText(_translate("MainWindow", "kill"))
        self.exec_but.setText(_translate("MainWindow", "exec"))
        self.dup_but.setText(_translate("MainWindow", "dup"))
        self.system_but.setText(_translate("MainWindow", "system"))
        self.sig_but.setText(_translate("MainWindow", "signal"))
        self.pipe_but.setText(_translate("MainWindow", "pipe"))
        self.mkfifo_but.setText(_translate("MainWindow", "mkfifo"))
        self.alarm_but.setText(_translate("MainWindow", "alarm"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.Programme_tab), _translate("MainWindow", "Programme"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.output_tab), _translate("MainWindow", "Output"))
        self.plainTextEdit.setPlainText(_translate("MainWindow", "\n"
"\n"
"fork() creates a new process by duplicating the calling process.The new process is referred to as the child process. The calling process is referred to as the parent process."))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
