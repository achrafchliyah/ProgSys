import PyQt5.QtWidgets as qtw
import PyQt5.QtGui as qtg

class MainWindow(qtw.QWidget):
	def __init__(self):
		super().__init__()

		self.setWindowTitle("Hello WOrld!")

		self.setLayout(qtw.QVBoxLayout())


		my_label = qtw.QLabel("Fork")
		my_label.setFont(qtg.QFont("Helvetica", 18))
		self.layout().addWidget(my_label)
		

		my_text = qtw.QTextEdit(self,
			plainText="this is areal",
			lineWrapMode =qtw.QTextEdit.FixedColumnWidth,
			lineWrapColumnOrWidth=50,
			placeholderText="hellol",
			readOnly=False,
			)

		self.layout().addWidget(my_text)
		#my_spin.setFont(qtg.QFont("Helvetica", 24))






		#my_combo = qtw.QComboBox(self,
		#	editable = True,
		#	insertPolicy=qtw.QComboBox.InsertAtTop)
		#my_combo.addItem('alarm', "s")
		#my_combo.addItem('exec', 2)
		#my_combo.addItem('fork')
		#my_combo.addItem('signal', qtw.QWidget)
		#my_combo.addItem('sleep')
		#self.layout().addWidget(my_combo)


		#my_entry = qtw.QLineEdit()
		#my_entry.setObjectName("name_field")
		#my_entry.setText("dddddddd")
		#self.layout().addWidget(my_entry)

		my_Button = qtw.QPushButton("ress Me!", clicked = lambda: press_it())
		self.layout().addWidget(my_Button)

		self.show()

		def press_it():
			my_label.setText(f'Hello {my_text.toPlainText()}')
			my_text.setPlainText("you pressed fork")


			#my_entry.setText('')





app = qtw.QApplication([])
mw = MainWindow()



app.exec_()