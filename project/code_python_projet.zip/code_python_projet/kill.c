#include<stdio.h>
#include<signal.h>
#include<unistd.h>
void main(){
kill(-1, SIGKILL);
}
